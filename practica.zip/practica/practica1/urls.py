#practica1/urls.py
from django.urls import path
