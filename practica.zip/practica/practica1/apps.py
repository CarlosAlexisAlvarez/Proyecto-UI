from django.apps import AppConfig


class Practica1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'practica1'
